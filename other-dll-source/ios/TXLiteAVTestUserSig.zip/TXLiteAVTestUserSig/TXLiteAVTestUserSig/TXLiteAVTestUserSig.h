//
//  TXLiteAVTestUserSig.h
//  TXLiteAVTestUserSig
//
//  Created by gavinwjwang on 2021/12/3.
//

#import <Foundation/Foundation.h>

@interface TXLiteAVTestUserSig : NSObject

@end
